package main 

import "fmt"

func main(){
	//print name in morse code
	//chris = -.-. .... .-. .. ...
	fmt.Println("-.-. .... .-. .. ...")
}