package main

import "fmt"

func main(){
	//print name in large letters using asterisks
	fmt.Println(
		"*******      *      *      *******      *******       *******\n" +
		"*            *      *      *     *         *          *\n" +
		"*            *      *      *     *         *          *\n" + 
		"*            *      *      *******         *          *\n" +
		"*            *      *      **              *          *******\n" + 
		"*            ********      * *             *                *\n" +
		"*            *      *      *  *            *                *\n" +
		"*            *      *      *   *           *                *\n" +
		"*            *      *      *    *          *                *\n" +
		"*******      *      *      *     *      *******       *******")
	
}